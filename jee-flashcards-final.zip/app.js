const subjectChapters = {
  Physics: ["Kinematics", "NLM"],
  Chemistry: ["Atomic Structure", "Periodic Table"],
  Maths: ["Binomial Theorem", "PNC"]
};

const subjectSelect = document.getElementById("subject");
const chapterSelect = document.getElementById("chapter");
const flashcard = document.getElementById("flashcard");
const card = document.getElementById("card");
const questionBox = document.getElementById("question");
const answerBox = document.getElementById("answer");
const revealBtn = document.getElementById("reveal");
const nextBtn = document.getElementById("next");

let questions = [];
let current = null;

subjectSelect.addEventListener("change", () => {
  const subject = subjectSelect.value;
  chapterSelect.innerHTML = '<option value="">--Choose--</option>';
  if (subject && subjectChapters[subject]) {
    subjectChapters[subject].forEach(ch => {
      const opt = document.createElement("option");
      opt.value = ch;
      opt.textContent = ch;
      chapterSelect.appendChild(opt);
    });
    chapterSelect.disabled = false;
  } else {
    chapterSelect.disabled = true;
  }
});

chapterSelect.addEventListener("change", () => {
  const chapter = chapterSelect.value;
  if (chapter) {
    const filename = `formulas/${chapter.toLowerCase().replace(/\s+/g, '_')}.json`;
    fetch(filename)
      .then(res => res.json())
      .then(data => {
        questions = data;
        flashcard.classList.remove("hidden");
        nextQuestion();
      });
  }
});

function nextQuestion() {
  const index = Math.floor(Math.random() * questions.length);
  current = questions[index];
  card.classList.remove("flipped");
  questionBox.textContent = current.question;
  answerBox.innerHTML = "";
}

revealBtn.addEventListener("click", () => {
  card.classList.add("flipped");
  katex.render(current.answer, answerBox, { throwOnError: false });
});

nextBtn.addEventListener("click", () => {
  nextQuestion();
});
