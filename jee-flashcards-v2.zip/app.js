const subjects = {
  Physics: ['Kinematics', 'NLM'],
  Chemistry: ['Atomic Structure', 'Periodic Table'],
  Maths: ['Binomial Theorem', 'PNC'],
};
let selectedSubject = null;
let selectedChapter = null;
let questions = [];
let current = null;

const subjectButtons = document.querySelectorAll('.subject-btn');
const chapterContainer = document.getElementById('chapter-selection');
const chapterList = document.getElementById('chapter-list');
const chapterTitle = document.getElementById('chapter-title');
const questionBox = document.getElementById('question-box');
const answerBox = document.getElementById('answer-box');
const flashcard = document.getElementById('flashcard');
const flipInner = document.getElementById('flip-inner');

subjectButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    selectedSubject = btn.dataset.subject;
    showChapters(selectedSubject);
  });
});

function showChapters(subject) {
  chapterContainer.classList.remove('hidden');
  chapterTitle.textContent = `Select a Chapter in ${subject}`;
  chapterList.innerHTML = '';
  subjects[subject].forEach(chap => {
    const li = document.createElement('li');
    li.textContent = chap;
    li.addEventListener('click', () => loadChapter(chap));
    chapterList.appendChild(li);
  });
}

function loadChapter(chapter) {
  selectedChapter = chapter;
  const file = `formulas/${chapter.toLowerCase().replace(/\s+/g, '_')}.json`;
  fetch(file)
    .then(res => res.json())
    .then(data => {
      questions = data;
      nextQuestion();
      document.getElementById('selector').classList.add('hidden');
      flashcard.classList.remove('hidden');
    })
    .catch(err => alert('Error loading formulas: ' + err));
}

function nextQuestion() {
  const rand = Math.floor(Math.random() * questions.length);
  current = questions[rand];
  flipInner.classList.remove('flipped');
  questionBox.textContent = current.question;
  answerBox.innerHTML = '';
}

document.getElementById('reveal-btn').addEventListener('click', () => {
  katex.render(current.answer, answerBox, { throwOnError: false });
  flipInner.classList.add('flipped');
});

document.getElementById('next-btn').addEventListener('click', nextQuestion);
