const subjects = {
  Physics: ['Kinematics', 'NLM'],
  Chemistry: ['Atomic Structure', 'Periodic Table'],
  Maths: ['Binomial Theorem', 'PNC'],
};
let selectedSubject = null;
let selectedChapter = null;
let questions = [];
let current = null;
const subjectButtons = document.querySelectorAll('.subject-btn');
const chapterContainer = document.getElementById('chapter-selection');
const questionBox = document.getElementById('question-box');
const answerBox = document.getElementById('answer-box');
const flashcard = document.getElementById('flashcard');
subjectButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    selectedSubject = btn.dataset.subject;
    showChapters(selectedSubject);
  });
});
function showChapters(subject) {
  chapterContainer.classList.remove('hidden');
  chapterContainer.innerHTML = `<h2>Select a Chapter in ${subject}</h2>`;
  subjects[subject].forEach(chap => {
    const btn = document.createElement('button');
    btn.textContent = chap;
    btn.className = 'chapter-btn';
    btn.addEventListener('click', () => loadChapter(chap));
    chapterContainer.appendChild(btn);
  });
}
function loadChapter(chapter) {
  selectedChapter = chapter;
  const file = `formulas/${chapter.toLowerCase().replace(/\s+/g, '_')}.json`;
  fetch(file)
    .then(res => res.json())
    .then(data => {
      questions = data;
      nextQuestion();
      document.getElementById('selector').classList.add('hidden');
      flashcard.classList.remove('hidden');
    })
    .catch(err => alert('Error loading formulas: ' + err));
}
function nextQuestion() {
  const rand = Math.floor(Math.random() * questions.length);
  current = questions[rand];
  questionBox.textContent = current.question;
  answerBox.classList.add('hidden');
  answerBox.innerHTML = '';
}
document.getElementById('reveal-btn').addEventListener('click', () => {
  answerBox.classList.remove('hidden');
  katex.render(current.answer, answerBox, { throwOnError: false });
});
document.getElementById('next-btn').addEventListener('click', nextQuestion);
